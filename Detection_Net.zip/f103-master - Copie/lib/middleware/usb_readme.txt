
La librairie USB ne peut pas �tre compil�e pour g�rer le mode DEVICE et le mode HOST.
Il faut fait un choix � la compilation entre ces deux modes...

Mode Device : la carte est consid�r�e comme un p�riph�rique USB par l'ordinateur sur laquelle on l'a branch�e.
	Par exemple, elle peut se faire reconnaitre comme une souris, un clavier, ou un p�riph�rique de stockage de masse.
	
Mode Host : la carte acceuille des p�riph�riques USB. 
	Par exemple une cl� USB, une souris...
	
	
Pour changer de mode :

Il faut activer la macro USE_DEVICE_MODE ou USE_HOST_MODE dans lib/middleware/usb_conf.h

Il faut ensuite d�sactiver la compilation de l'un des deux dossiers lib/middleware/usb_host ou lib/middleware/usb_device :
   1 - bouton droit sur le dossier � d�sactiver
   2 - Ressource configuration
   3 - Exclude from Build
   4 - Cocher les modes de compilations pour lesquels on souhaite cocher cette exclusion (tous...)
L'op�ration inverse (d�cocher...) permet de r�activer la compilation du mode souhait�.

