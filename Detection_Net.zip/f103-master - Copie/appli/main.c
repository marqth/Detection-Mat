/**
  ******************************************************************************
  * @file    main.c
  * @author  Nirgal
  * @date    03-July-2019
  * @brief   Default main function.
  ******************************************************************************
*/
#include "stm32f1_timer.h"
#include "stm32f1xx_hal.h"
#include "tft_ili9341/stm32f1_ili9341.h" //pour l'ecran
#include "stm32f1_sys.h"
#include "stm32f1_gpio.h"
#include "macro_types.h"
#include "systick.h"
#include "stm32f1_adc.h" //pour les photoresistances
#include "stm32f1_pwm.h" //pour le moteur

void writeLED(bool_e b)
{
	HAL_GPIO_WritePin(LED_GREEN_GPIO, LED_GREEN_PIN, b);
}

static volatile uint32_t t = 0;
void process_ms(void)
{
	if(t)
		t--;
}


int main(void)
{
	//Initialisation de la couche logicielle HAL (Hardware Abstraction Layer)
	//Cette ligne doit rester la premi�re �tape de la fonction main().

	HAL_Init();

	//Initialisation du port de la led Verte (carte Nucleo)
	BSP_GPIO_PinCfg(LED_GREEN_GPIO, LED_GREEN_PIN, GPIO_MODE_OUTPUT_PP,GPIO_NOPULL,GPIO_SPEED_FREQ_HIGH);

	//Initialisation du port du bouton bleu (carte Nucleo)
	BSP_GPIO_PinCfg(BLUE_BUTTON_GPIO, BLUE_BUTTON_PIN, GPIO_MODE_INPUT,GPIO_PULLUP,GPIO_SPEED_FREQ_HIGH);

	//On ajoute la fonction process_ms � la liste des fonctions appel�es automatiquement chaque ms par la routine d'interruption du p�riph�rique SYSTICK
	Systick_add_callback_function(&process_ms);

	int reference= 2900;	//Valeur seuil en de�a de laquelle les photor�sitances doivent aller pour que l'on consid�re qu'un position est d�tect�e

	int volatile luminosite[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Tableau dans lequel on r�cup�re les valeurs r�cip�r�es par les photor�sistances

	int32_t angles[4][4] = { {21, 7, -7, -21},   //Matrice des angles des points pour le moteur pas � pas
		                     {26, 9, -9, -26},
		                     {35, 13, -13, -35},
							 {50, 21, -21, -50}};

	int16_t positions_points[4][4][2] = { { {34,104}, {34,162}, {34,219}, {34,276}}, //Matrice des coordonn�es des points � afficher sur l'�cran
								 	  	  { {92,104}, {92,162}, {92,219}, {92,276}},
										  { {149,104}, {149,162}, {149,219}, {149,276}},
										  { {206,104}, {206,162}, {206,219}, {206,276}}};

	int16_t positions_colonnes[4][4] = { {34, 90, 34, 290}, //Matrice des coordonn�es des colonnes � afficher sur l'�cran
										 {92, 90, 92, 290},
										 {149, 90, 149, 290},
										 {206, 90, 206, 290}};

	int16_t positions_lignes[4][4] = { {20, 104, 220, 104}, //Matrice des coordon�es des lignes � afficher sur l'�cran
									   {20, 162, 220, 162},
									   {20, 219, 220, 219},
									   {20, 276, 220, 276}};

	int32_t angle_colonnes[4] = {27,10,-10,-27}; //Tableau des angles des colonnes pour le moteur pas � pas

	int tab_intersection[2] = {-1, -1}; //Tableau o� l'on enregistre les num�ros de la ligne et de la colonne o� on d�tecte une pression sur le tapis

	int memo_intersection[2] = {-1, -1}; //Tableau m�mo afin de ne pas actualiser l'�cran en permanence et optimiser ses performances


	//Fonction permettant de r�cup�rer le num�ro de la ligne et de la colonne o� une pr�sence est d�tect�e

	void intersection (int luminosite[8]){
		for (int i=0;i<2;i++){
			tab_intersection[i] = -1;
		}
		for (int i=0;i<4;i++){
			if (tab_intersection[0]!=-1) {
				i = 4;
			}else if (luminosite[i]<reference){
				tab_intersection[0] = i;
			}else{
				tab_intersection[0] = -1;
			}
		}
		for (int j=4;j<8;j++){
			if (tab_intersection[1]!=-1) {
				j = 8;
			}else if (luminosite[j]<reference){
				tab_intersection[1] = j-4;
			}else{
				tab_intersection[1] = -1;
			}
		}
	}



	//Fonction permettant de r�cup�rer les valeurs capt�es par les photor�sistances
	void recup_lumino () {
		luminosite[0] = ADC_getValue(ADC_0);
		luminosite[1] = ADC_getValue(ADC_1);
		luminosite[2] = ADC_getValue(ADC_2);
		luminosite[3] = ADC_getValue(ADC_3);
		luminosite[4] = ADC_getValue(ADC_4);
		luminosite[5] = ADC_getValue(ADC_5);
	    luminosite[6] = ADC_getValue(ADC_6);
		luminosite[7] = ADC_getValue(ADC_7);
	}


	//Fonction affichage pour les points  // l ecran fait 240*320
	void AffichageEcran (int16_t coordX, int16_t coordY){
		ILI9341_Fill(ILI9341_COLOR_WHITE);
		ILI9341_DrawFilledRectangle(20, 90, 220, 290, ILI9341_COLOR_BLACK); //rectangle definissant le tapis
		ILI9341_DrawFilledCircle(coordX, coordY, 5, ILI9341_COLOR_WHITE); // cercle representant la personne
	}


	void AffichageEcran_colonnes (int16_t tableau){ //Fonction affichage pour les colonnes
		ILI9341_Fill(ILI9341_COLOR_WHITE);
		ILI9341_DrawFilledRectangle(20, 90, 220, 290, ILI9341_COLOR_BLACK); //rectangle definissant le tapis
		ILI9341_DrawFilledCircle(120, 320, 5, ILI9341_COLOR_BLACK); //cercle representant la camera
		ILI9341_DrawLine(positions_colonnes[tableau][0],positions_colonnes[tableau][1],positions_colonnes[tableau][2],positions_colonnes[tableau][3], ILI9341_COLOR_WHITE); // Ligne repr�sentant la colonne sur laquelle est la personne
	}

	void AffichageEcran_lignes (int16_t tableau){ //Fonction affichage pour les lignes
		ILI9341_Fill(ILI9341_COLOR_WHITE);
		ILI9341_DrawFilledRectangle(20, 90, 220, 290, ILI9341_COLOR_BLACK); //rectangle definissant le tapis
		ILI9341_DrawFilledCircle(120, 320, 5, ILI9341_COLOR_BLACK); //cercle representant la camera
		ILI9341_DrawLine(positions_lignes[tableau][0],positions_colonnes[tableau][1],positions_colonnes[tableau][2],positions_colonnes[tableau][3], ILI9341_COLOR_WHITE); // Ligne repr�sentant la colonne sur laquelle est la personne
	}


	void programme (int tableau[2]) { //Fonction permettant d'utiliser l'�cran et le moteur lorsqu'une position est d�tect�e
		if ((tableau[0]!=-1)&&(tableau[1]!=-1)){
			STEPPER_MOTOR_set_goal(0,angles[tableau[0]][tableau[1]]);
			STEPPER_MOTOR_reach_goal ();
			ILI9341_Fill(ILI9341_COLOR_WHITE);
			AffichageEcran(positions_points[tableau[1]][tableau[0]][0],positions_points[tableau[1]][tableau[0]][1]);
			ILI9341_DrawFilledCircle(120, 320, 5, ILI9341_COLOR_BLACK); //cercle representant la camera
			ILI9341_printf(25, 20, &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE,"Une personne a ete detectee");
		}else if ((tableau[0]==-1)&&(tableau[1]!=-1)){
			STEPPER_MOTOR_set_goal(0,angle_colonnes[tableau[1]]);
			STEPPER_MOTOR_reach_goal ();
			AffichageEcran_colonnes(tableau[1]);
			ILI9341_printf(10, 10, &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE,"Une personne a ete detectee sur une des colonnes");
		}else if ((tableau[0]!=-1)&&(tableau[1]==-1)){
			AffichageEcran_lignes(tableau[0]);
			ILI9341_printf(10, 10, &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE,"Une personne a ete detectee sur une des lignes");
		}else{
			STEPPER_MOTOR_set_goal(0,0);
			STEPPER_MOTOR_reach_goal ();
			ILI9341_Fill(ILI9341_COLOR_WHITE);
			ILI9341_DrawFilledRectangle(20, 90, 220, 290, ILI9341_COLOR_BLACK); //rectangle definissant le tapis
			ILI9341_DrawFilledCircle(120, 320, 5, ILI9341_COLOR_BLACK); //cercle representant la camera
			ILI9341_printf(10, 10, &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE,"Aucune personne n'a ete detectee");
		}
	}

	ADC_init(); //initialisation des ports ADC
	STEPPER_MOTORS_init(); //initialisation du moteur pas � pas
	ILI9341_Init(); //initialisation de l'�cran
	ILI9341_DrawFilledRectangle(20, 90, 220, 290, ILI9341_COLOR_BLACK); //rectangle definissant le tapis
	ILI9341_DrawFilledCircle(120, 320, 5, ILI9341_COLOR_BLACK); //cercle representant la camera
	while(1)	//boucle de t�che de fond
		{
		recup_lumino();
		intersection (luminosite);
		if(memo_intersection[0] == tab_intersection[0] && memo_intersection[1] == tab_intersection[1]){ //Si la position d�tect�e est la m�me qu'� l'it�ration pr�c�dente, il est inutile d'actualiser l'�cran et le moteur
			Delay_us(1);
		}else{
			memo_intersection[0] = tab_intersection[0];
			memo_intersection[1] = tab_intersection[1];
			programme(tab_intersection);
		Delay_ms(2000);
		}
	}
}
