/*
 * esp8266.h
 *
 *  Created on: 24 f�vr. 2017
 *      Author: Nirgal
 */

#ifndef BSP_ESP8266_ESP8266_H_
#define BSP_ESP8266_ESP8266_H_

void ESP8266_demo(void);
void ESP8266_init(void);
void ESP8266_exemple(char* nomWifi, char* password);

#endif /* BSP_ESP8266_ESP8266_H_ */
